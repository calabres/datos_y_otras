import sys
import os
import s3fs
import xarray as xr
import numpy as np
import pandas as pd
import pyproj
from datetime import datetime, timedelta
import warnings

# Suprimir avisos molestos de pyproj/xarray si los hubiera
warnings.filterwarnings('ignore')

def procesar_dia(fecha, fs, y_slice, x_slice, horas_madrugada):
    year = fecha.strftime('%Y')
    doy = fecha.strftime('%j')
    
    # Cambio automático de satélite (Transición Abril 2025)
    bucket = 'noaa-goes19/ABI-L2-LSTF' if fecha >= datetime(2025, 4, 7) else 'noaa-goes16/ABI-L2-LSTF'
    
    archivos = []
    for h in horas_madrugada:
        path = f'{bucket}/{year}/{doy}/{h}/'
        if fs.exists(path):
            archivos.extend(fs.ls(path))
    
    if not archivos: 
        print(f"  -> No se encontraron archivos satelitales en S3 para esta fecha.")
        return None

    print(f"  -> Se detectaron {len(archivos)} archivos en S3. Procesando...")

    datasets = []
    for a in archivos:
        try:
            with fs.open(a, 'rb') as f:
                # Abrimos directamente desde la memoria
                ds = xr.open_dataset(f, engine='h5netcdf').sel(y=y_slice, x=x_slice)[['LST', 'goes_imager_projection']]
                ds = ds.rename({'t': 'time'}).expand_dims('time').load()
                datasets.append(ds)
        except Exception as e:
            print(f"     [!] Error abriendo el archivo {a}: {str(e)}")
            continue

    if not datasets: 
        print("  -> Se encontraron archivos pero ninguno pudo abrirse correctamente.")
        return None

    # Concatenamos la madrugada completa
    ds_noche = xr.concat(datasets, dim='time')
    
    # 1. VALOR DE TMIN
    ds_tmin = ds_noche['LST'].min(dim='time')
    
    # 2. HORA DE TMIN (UTC)
    ds_hora = ds_noche['LST'].idxmin(dim='time')

    # Transformación de Coordenadas
    proj_info = datasets[0].goes_imager_projection
    p = pyproj.Proj(proj='geos', h=proj_info.perspective_point_height, 
                    lon_0=proj_info.longitude_of_projection_origin, 
                    sweep=proj_info.sweep_angle_axis)
    
    # x e y a nivel meshgrid
    x_val, y_val = np.meshgrid(ds_tmin.x * proj_info.perspective_point_height, 
                               ds_tmin.y * proj_info.perspective_point_height)
    lon, lat = p(x_val, y_val, inverse=True)

    # DataFrame de resultados
    df = ds_tmin.to_dataframe().reset_index()
    df['lat'] = lat.flatten()
    df['lon'] = lon.flatten()
    df['tmin_c'] = df['LST'] - 273.15 # Kelvin a Celsius
    
    # Procesamos la hora: Convertimos UTC a Argentina (-3 horas)
    tiempos_utc = ds_hora.values.flatten()
    df['hora_local'] = pd.to_datetime(tiempos_utc) - timedelta(hours=3)
    df['hora_local'] = df['hora_local'].dt.strftime('%H:%M')
    
    # Agregamos la columna de fecha constante para este archivo
    df['fecha'] = fecha.strftime('%Y-%m-%d')

    # Limpieza final: filtramos datos nulos y recortamos la caja exacta de coordenadas
    # (Usando los mismos límites que usamos en ERA5: Lat -21 a -41, Lon -68 a -53)
    df = df.dropna(subset=['tmin_c'])
    df = df[(df['lat'] <= -21) & (df['lat'] >= -41)]
    df = df[(df['lon'] >= -68) & (df['lon'] <= -53)]
    
    # Si después del filtro quedó vacío
    if df.empty:
        return None
        
    return df[['lat', 'lon', 'tmin_c', 'hora_local', 'fecha']]

def main():
    if len(sys.argv) != 3:
        print("Parametros incorrectos. Uso interno por el batch script.")
        sys.exit(1)
        
    start_str = sys.argv[1]
    end_str = sys.argv[2]
    
    try:
        fecha_inicio = datetime.strptime(start_str, "%d%m%Y")
        fecha_fin = datetime.strptime(end_str, "%d%m%Y")
    except ValueError:
        print("Error: El formato de fechas debe ser DDMMAAAA (Por ejemplo, 01022026)")
        sys.exit(1)
        
    if fecha_inicio > fecha_fin:
        print("Error: La fecha inicial no puede ser posterior a la fecha final.")
        sys.exit(1)

    # --- CONFIGURACIÓN REQUERIDA DE LA APLICACIÓN ---
    horas_madrugada = ['03', '04', '05', '06', '07', '08', '09', '10']
    
    # Bounding Box ampliado para abarcar Sudamérica en Radianes 
    # (El satélite GOES mira desde el ecuador a -75.2W. Argentina está al sur (y negativo) y un poco al este (x positivo) del centro)
    y_slice = slice(-0.02, -0.15)
    x_slice = slice(0.00, 0.10)

    print(f"\nIniciando cliente AWS S3...")
    fs = s3fs.S3FileSystem(anon=True)
    
    output_dir = "archivos_diarios_goes"
    os.makedirs(output_dir, exist_ok=True)

    print(f"Descargando GOES LST (Temperatura de Superficie) del {fecha_inicio.strftime('%Y-%m-%d')} al {fecha_fin.strftime('%Y-%m-%d')}...\n")

    fecha_actual = fecha_inicio
    while fecha_actual <= fecha_fin:
        print(f"[{fecha_actual.strftime('%Y-%m-%d')}] Consultando satelite...", end=" ")
        try:
            resultado = procesar_dia(fecha_actual, fs, y_slice, x_slice, horas_madrugada)
            if resultado is not None:
                nombre = os.path.join(output_dir, f"tmin_arg_{fecha_actual.strftime('%Y%m%d')}.txt")
                resultado.to_csv(nombre, sep='\t', index=False, float_format='%.2f')
                print(f"OK >> Creado 'tmin_arg_{fecha_actual.strftime('%Y%m%d')}.txt' ({len(resultado)} pixeles validos)")
            else:
                print(f"Sin datos completos para calcular madrugada.")
        except Exception as e:
            print(f"Error procesando este dia: {e}")
        
        fecha_actual += timedelta(days=1)
        
    print("\nPROCESO FINALIZADO.")
    print(f"Revisa los resultados generados en la carpeta: {os.path.abspath(output_dir)}")

if __name__ == "__main__":
    main()
