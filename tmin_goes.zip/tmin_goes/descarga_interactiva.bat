@echo off
setlocal enabledelayedexpansion
title Descargador TMIN - GOES Satelites NOAA

echo =========================================================
echo    Herramienta de Descarga de Temperatura Minima (GOES/LST)
echo =========================================================
echo.
echo Los resultados quedaran guardados en "archivos_diarios_goes".
echo.
echo Por favor introduzca las fechas en el siguiente formato: DDMMAAAA
echo (Por ejemplo, para 01 de Enero de 2026 ingrese: 01012026)
echo.

set /p FECHA_INICIO="Desde que fecha desea descargar? (DDMMAAAA): "
set /p FECHA_FIN="Hasta que fecha desea descargar? (DDMMAAAA): "

echo.
echo =========================================================
echo Buscando Python en el sistema...
echo =========================================================
set PYTHON_CMD=python
py --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_CMD=py
)

echo Usando ejecutable oficial: %PYTHON_CMD%

echo.
echo =========================================================
echo Verificando dependencias en la nube (puede demorar un poco la primera vez)...
echo =========================================================
%PYTHON_CMD% -c "import s3fs, xarray, numpy, pandas, pyproj, h5netcdf, h5py" 2>nul
if %errorlevel% neq 0 (
    echo Instalando librerias necesarias S3 Xarray PyProj h5netcdf h5py etc...
    %PYTHON_CMD% -m pip install -q s3fs xarray numpy pandas pyproj h5netcdf h5py
    echo Librerias instaladas correctamente.
) else (
    echo Dependencias listas...
)

echo.
echo =========================================================
echo Conectando a los satelites NOAA GOES...
echo =========================================================
%PYTHON_CMD% download_goes.py %FECHA_INICIO% %FECHA_FIN%

echo.
echo =========================================================
pause
